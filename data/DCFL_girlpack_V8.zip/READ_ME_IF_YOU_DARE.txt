Hi! Welcome to girlpack, Mitpack for Dr. Robotnik's Ring Racers. You're currently reading the notepad version, not the cooler, hipper version in the actual .pk3 file.

This is the Lua version of girlpack, organized by Superstarxalien.

--VERSION 8 --

This pack features the following:

Fourteen racers:
Aerith [4/3]
Tifa [6/5]
Cloud [7/7]
Barret [2/9]
Aeris the Spaniel [5/2]
Juri [9/3]
Morrigan [6/6]
Kiriko (Witch) [8/2]
Lucas [3/4]
Kumatora [7/3]
Dr. Orpheus [4/8]
Ramona Flowers [6/7]
Spider-Man [8/3]
Gwenpool [3/2]

Nine custom colors:
"Wine" (Tifa)
"SOLDIER" (Cloud)
"Feng Shui" (Juri)
"Succubus" (Morrigan)
"Clash" (Spider-Man)
"Symbiote"
"Trans Pride"
"Lesbian Pride"
"Bi Pride"
"Non-binary Pride"

and sixteen  followers:
JENOVA, Chibi Sephiroth, Chibi Aerith, Chadley, Plush Aerith, Low-Poly Cloud, Low-Poly Tifa, Low-Poly Aerith, Low-Poly Barret, Limit Gauge, Moogle (FF7)
Juri-Chan (Street Fighter)
EricBound, Balloon Mr. Saturn (MOTHER)
Speech bubble (Marvel)
Pride Flag (Pride)

Special thanks to: 
Superstarxalien for helping organize this .pk3 so it can all be loaded as one file without errors.

Knuckleschaotix/Becky for helping me gather voice clips for Dr. Orpheus and Ramona in high quality.


If you're reading this, and you're wondering about any of the remaining characters from my previous pack, 
please know that I currently have no concrete plans for any particular characters to be brought over, let alone any 
major commitment to keeping this pack upkept. I know that a lot of my characters were widely used in SRB2Kart, however
a lot of my motivation to stick with this and make characters and content people wanted has been pretty exhausted over time.
If there will be any major difference to find in the future of this pack, it will be that it will more closely cater to me, with more particular 
inclusions and more glaring omissions. I don't like announcing what I want to do because my whims tend to change moment to moment.

If your character doesn't end up getting ported by me personally, I'm sorry- though I can't stop you from doing it yourself, 
of course (I only ask you not release them publicly if you do).