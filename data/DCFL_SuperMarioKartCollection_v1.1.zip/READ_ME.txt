Thank you for downloading the Super Mario Kart Collection! This pack is a labor of love for the Super Mario series and features a wide selection of racers and followers from its history.

This pack is technically an offshoot of girlpack, my main character pack, and features some content previously featured there. You can find girlpack here: https://mb.srb2.org/addons/girlpack.6723/

SUPER MARIO COLLECTION v1.1

-=RACERS=-

Mario 5/5 [supermario]
Luigi 6/4 [superluigi]
Peach 3/3 [peach]
Toad 8/2 [toad] | Toad (Monochrome) [toad_c]
Yoshi 8/6 [yoshi] (If you'd like to use Yoshi's modern voice, load DC_SMKC_YoshiVoiceSwap.pk3 AFTER DCFL_SuperMarioKartCollection.pk3!)
Donkey Kong Jr. 3/8 [dkjunior]
Bowser 8/9 [bowser]
Koopa 2/3 [koopatroopa]
Goomba 2/4 [goomba]
Thwomp 1/9 [thwomp]
Birdo 3/6 [birdo_sma]
Gameboy Wario 5/9 [wario_gb]
Banana Peel 2/1 [bananapeel]
Paper Mario 6/2 [papermario]
Tanooki Mario 5/2 [tanookimario] (Toggle Statue Mario with the "statuemario" command. Enabled by default)

-=FOLLOWERS=-
Baby Yoshi
Boo (Luigi's Mansion)
Dash Mushroom
Eternal Star
Fuzzy (Paper Mario)
Fuzzy (Yoshi's Island)
Golden Coin
goombakart
Green Demon
Phanto
Poison Mushroom (Super Mario Kart)
Koopa Shell
Key
Super Star
Wega
Weird Mushroom

-=COLORS=-

"Mario" (Used by Mario, Toad)
"Luigi" (Used by Luigi)
Troopa" (Used by Bowser, Koopa)
"Paratroopa" (Alternate color for Koopa)
"Loud" (Used by Gameboy Wario)
"M Emblem" (Used by Paper Mario)
"Soda Lime"
"Luster"
"Bluster"
"Chestnut"


Special thanks to the following users for their help and motivation with the completion of this pack:

Superstarxalien for setting up goombakart to have additional rotations.

Sin Cama for their additional Ring Racer kart templates, which were used for Bowser, Thwomp, Donkey Kong Jr., and Gameboy Wario.

Amy Farbright for helping me gather voice clips for Birdo in high quality.

Jaituia for creating the Lua script for Tanooki Mario.

toastergrl for assisting with Tanooki Mario's Lua scripting.

CrappyBlue for creating the FM sound effect for Tanooki Mario's transformation.